package com.apipothi.amazon.AMAZON;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AmazonApplicationTests {

	@Test
	void contextLoads() {
	}

}
